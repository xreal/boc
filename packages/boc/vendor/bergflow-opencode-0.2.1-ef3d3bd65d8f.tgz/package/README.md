# Bergflow

Bergflow 0.2.1 provides project capability controls through OpenCode V2 plugin RPC. Boc includes the same portable artifact; original OpenCode can load a trusted built checkout or an unpacked package. Controls need no integration credentials and do not change capabilities until an override is saved.

This is a private preview, not a published npm release. Tested original CLI versions are `0.0.0-beta-19192` (Boc's server pin) and `0.0.0-beta-19234`. Other versions are not yet promised. Runtime compatibility uses public plugin capabilities and protocol `bergflow.control.v1`, not exact Bergflow package-version equality.

## Optional integrations (`integrations: true`)

### Agents

- `forge`: hands-on investigation, implementation, and verification; the default agent
- `atlas`: strategic exploration, decision support, and decomposition
- `librarian`: read-only external documentation and source research

Forge and Atlas can be selected for normal sessions or launched as subagents. They inherit OpenCode's selected model unless configured otherwise. Librarian is a subagent and defaults to GPT-5.6 Terra with reasoning disabled. It allows normal research commands, asks before destructive Git operations such as pushing, resetting, or merging a pull request, and denies edits and nested delegation.

### Skills

- `code-review`
- `grilling`
- `devenv`
- `jira-confluence`
- `browserstack-test-management`
- `browser-qa`

Skills are advertised on demand instead of adding every procedure to every prompt. `browser-qa` requires an existing `agent-browser` installation, which Bergflow does not yet bundle. `devenv` expects the development wrappers used by the target project.

### Tools

- `bergflow_jira_read`: exact issue lookup and bounded JQL search
- `bergflow_confluence_read`: exact page lookup and bounded CQL search
- `bergflow_jira_write`: one create or update after confirmation of the exact payload
- `bergflow_shop_db_query`: bounded read-only local MySQL queries in detected Shop projects

## Quick start

Build a trusted checkout with Bun:

```sh
bun install --frozen-lockfile
bun run build
```

Add its absolute directory to the target project's `opencode.jsonc`:

```jsonc
{ "plugins": ["/path/to/bergflow"] }
```

Use the package directory, not `dist/server.js`: the package's `server.js` and `tui.js` entries allow automatic TUI discovery. No second CLI registration is needed. An archive can be installed into a trusted directory with `bun add /path/to/bergflow-opencode-0.2.1.tgz`; configure that directory's `node_modules/@bergflow/opencode` path in the same way. The package is not currently published to npm. The official `opencode2 plugin add` command accepts registry/Git specs and modifies global server configuration; it does not accept local archives/directories.

In Boc, open **Bergflow Controls** from navigation or the session command. The bundled default requires no plugin download. An explicitly configured external Bergflow takes precedence, including its options; a disabled or broken external source is never silently replaced. A remote administrator must install the plugin on that server. Opening Controls never installs, restarts, or replaces a server.

## Project controls

Use **Bergflow control**, `<leader>k`, or the command palette in the TUI. Native Boc and TUI use the same authenticated RPC service and storage. Policy belongs to one project on one server; worktrees share overrides but retain separate inventories. Independent servers do not synchronize policy.

Skills, observed tools, configured MCP servers, and automatically discovered project `AGENTS.md` files are mutable when their required public APIs exist. Agents remain read-only. Instruction changes apply to future ambient loads; existing session history and nested instructions loaded while reading files are retained. Tools are an explicitly incomplete observed inventory. Already running actions continue; skill changes affect subsequent requests, tool changes affect subsequent model requests/execution, and MCP changes reload connections. Enabled MCP configuration does not imply authentication or a working connection.

Agent transforms are not a final policy phase: config runs after external plugins, and later `AgentEditor.update` registrations can recreate removed agents. Isolated probes on both tested original server versions confirmed that ordinary reloads preserve registration precedence rather than enforcing earlier exclusions. A delayed update listener is not an atomic fix. Boc exposes a versioned structured selection API for ambient instruction discovery, so Bergflow can exclude project files before rendering without text filtering. Original OpenCode servers and non-project instruction sources remain read-only. Read-triggered nested instruction loading is a separate path and is intentionally unchanged.

Revisions prevent concurrent clients from overwriting changes. A failed reload preserves the saved intent and supports **Retry applying saved setting**. **Use project default** removes an override. Following a timeout, refresh and inspect the state instead of repeating the mutation. Legacy overrides are retained, including unsupported agent/instruction choices marked unconfirmed; those can be cleared.

The old loopback browser panel and cache descriptor are removed in 0.2. Use the TUI or Boc; no replacement bridge or model-accessible policy-writing tool is installed. Existing plugin storage is adopted without editing repository configuration. On servers without structured selection, the read-only fallback inventory covers existing `AGENTS.md` files from the canonical root to a nested location; outside-root worktrees are marked incomplete.

## Configuration

All options are optional. Use the object form when the project needs Bergflow-specific settings:

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "plugins": [
    {
      "package": "/absolute/path/to/bergflow",
      "options": {
        "integrations": true,
        "models": {
          "forge": "openai/gpt-5.6-terra#high",
          "atlas": "openai/gpt-5.6-terra#high",
          "librarian": "openai/gpt-5.6-terra"
        },
        "git": {
          "baseBranch": "master",
          "branchTemplate": "{key}-{slug}",
          "remote": "origin"
        },
        "jira": {
          "baseUrl": "https://your-domain.atlassian.net",
          "auth": "basic",
          "emailEnv": "JIRA_EMAIL",
          "tokenEnv": "JIRA_API_TOKEN",
          "projectKey": "PC"
        },
        "confluence": {
          "baseUrl": "https://your-domain.atlassian.net/wiki"
        },
        "browserStackTestManagement": {
          "mcpName": "browserstack"
        },
        "shopDatabase": {
          "databaseEnv": "SHOP_DB_NAME",
          "userEnv": "SHOP_DB_USER",
          "passwordEnv": "SHOP_DB_PASSWORD"
        }
      }
    }
  ]
}
```

| Option | Behavior |
| --- | --- |
| `models.*` | Accepts `provider/model` with an optional `#variant`. Forge and Atlas otherwise inherit OpenCode's model. |
| `git.*` | Adds project Git defaults to Forge and Atlas. Defaults are `master`, `{key}-{slug}`, and `origin` when the section exists. |
| `jira.*` | Configures Jira's site, auth mode, credential environment names, and optional default create project. |
| `confluence.baseUrl` | Configures the Confluence site; authentication is shared with Jira. |
| `browserStackTestManagement.mcpName` | Names the configured BrowserStack Test Management MCP server. Defaults to `browserstack`. |
| `shopDatabase.*` | Names optional process-environment overrides for the local database credentials. The connection remains fixed to `127.0.0.1:3306`. |

Unknown keys and malformed model IDs, URLs, environment names, project keys, or branch templates fail while the plugin loads. Literal credentials are not accepted in plugin options.

## Credentials

Keep Atlassian secrets in the OpenCode process environment. Shop database credentials are read from the detected project's `shop/source/.env`; `SHOP_DB_*` variables can override them when needed:

```sh
export JIRA_EMAIL="you@example.com"
export JIRA_API_TOKEN="your-api-token"
export SHOP_DB_NAME="shop"
export SHOP_DB_USER="bergflow_readonly"
export SHOP_DB_PASSWORD="your-local-password"
```

When omitted from plugin options, non-secret Atlassian values fall back to `JIRA_BASE_URL`, `JIRA_AUTH`, `JIRA_PROJECT_KEY`, and `CONFLUENCE_BASE_URL`.

For OAuth, set `jira.auth` or `JIRA_AUTH` to `oauth` and provide the access token through the variable named by `tokenEnv`. The email variable is unused in OAuth mode.

## Safety Boundaries

Jira and Confluence requests use direct, bounded REST operations. Requests have a 15-second timeout and 2 MB response limit; each tool invocation has a 30-second deadline and a 500 KB output limit. Search results and pagination are bounded, and remote errors redact configured credentials.

Jira writes use a three-step flow: prepare the complete mutation, approve the returned payload in OpenCode's native question dialog, then execute the identical mutation immediately. Changed payloads, cancellation, reused confirmation, prior chat approval, and saved OpenCode approval cannot authorize a write.

The Shop database tool is registered only when the canonical project contains `shop/source/.env` and reads its conventional `DB_NAME`, `DB_USER`, and `DB_PASSWORD` values unless process-environment overrides are configured. Queries are restricted to one bounded `SELECT`, `SHOW`, `DESCRIBE`, or `EXPLAIN SELECT`, run in a read-only transaction, return at most 10 rows, and redact sensitive columns. A `SELECT` without a limit is automatically capped at 10 rows; an explicit limit must be a numeric literal of 10 or less. Always use a database account with read-only grants because SQL parsing is defense in depth, not authorization.

## Overrides

Native OpenCode precedence remains authoritative. Override a bundled agent or skill with the same ID in the normal global or project location:

```text
~/.config/opencode/agents/forge.md
.opencode/agents/forge.md
~/.config/opencode/skills/code-review/SKILL.md
.opencode/skills/code-review/SKILL.md
```

Set `disabled: true` in a same-ID agent definition to remove it, or set `default_agent` in `opencode.json(c)` to select a different default.

## Updating

Until Bergflow has a package distribution channel, update the trusted checkout, reinstall locked dependencies, rebuild, and restart OpenCode:

```sh
bun install --frozen-lockfile
bun run build
opencode2 service restart
```

## Development

Run the complete release gate before sharing a build:

```sh
bun run check
```

This runs the strict TypeScript check, focused test suite, production build, package-content check, import check, and isolated real-`opencode2` smoke test. Controls add explicit user policy writes; optional Jira mutations retain their native confirmation requirement. No custom service manager, installer, or updater is included.
