---
name: Browser QA
description: Performs frontend verification with agent-browser and existing end-to-end tests. Use for browser behavior, consent, tracking, console, network, screenshot, or end-to-end evidence.
---

# Browser QA

Use Vercel `agent-browser` for interactive browser work. Do not use Playwright,
Playwright MCP, or another browser automation tool. Keep checks on approved
local or test environments and confirm the delegated URL, account, and setup
before opening a browser.

## Runtime Guidance

- Before the first browser operation in a delegated task, run
  `agent-browser skills get core` and follow its version-matched command
  workflow within this skill's safety and evidence boundaries. Use
  `agent-browser skills get core --full` or `agent-browser skills list` when the
  task needs command details not present in the core overview.
- For exploratory testing, dogfooding, QA, or a bug hunt, also run
  `agent-browser skills get dogfood`. Load another specialized workflow only
  when it matches the delegated task.
- Do not install or update `agent-browser` during a normal verification pass. If
  the command or its browser is unavailable, report the prerequisite as an
  environment gap or `BLOCKED` when browser evidence is required. Installation,
  updates, profiles, host access, plugins, providers, and other sensitive
  capabilities require current explicit human approval.
- Use a simple named `--session` for isolation. Normal navigation, interaction,
  semantic locators, snapshots, waits, page evaluation, console/network
  inspection, and headed debugging are available. Keep uploads in delegated
  test fixtures and generated files in test or `browser-evidence/` paths.

## Session Setup

- Default to headless. Use `--headed` only when the delegation requests it or
  visual debugging is necessary; report the selected mode.
- When a local Bergfreunde target is implied but no URL is supplied, use
  `https://www.bergfreunde.de.localhost`. Do not infer staging, production, or
  another locale.
- Before meaningful interaction on a Bergfreunde target, navigate to the origin,
  set `bfUserCountry=false`, set localStorage
  `registrationPopupShownTime=2026-06-14T13:31:17.727Z`, accept all OneTrust
  cookies, then reload when needed. Record the resulting consent state.
- Accepting cookies, rather than bypassing the banner, is required for tracking
  assertions. When tracking matters, verify the active consent groups include
  `C0001`, `C0002`, `C0003`, and `C0004`.
- If a store-change prompt still appears, choose the option that remains on the
  current Bergfreunde store and report it.

## Execution

1. Restate the shortest user flow and the expected result from the delegated
   criterion. Stop as `BLOCKED` when an essential environment, account, or test
   datum is unavailable.
2. Use semantic accessibility snapshots and element references for navigation,
   fills, and clicks. Prefer visible text, URLs, form state, and focused
   screenshots over full-DOM dumps or brittle selectors.
3. Check keyboard interaction when the changed control is interactive. Inspect
   console errors and failed or unexpected network requests that can affect the
   scenario.
4. Capture a screenshot only when it proves the requested visual state. Write
   it below `browser-evidence/`; do not collect unrelated personal, account, or
   credential data.
5. For tracking criteria, verify the request caused by the exact interaction,
   not only a `data-mapp-click` attribute. Filter the observed requests for the
   expected `ct=<event-name>` and report its successful request and status.
6. Select the narrowest existing end-to-end spec and run it before adding
   coverage. Add or change a spec only when explicitly delegated, keep edits in
   test code or fixtures, avoid brittle timing or selectors, and rerun the
   focused spec.

## Experiments And Local Environments

- Set `optly_bergfreunde_test=1` only for an explicitly requested A/B,
  experiment, Optimizely, or variant check. State supplied variant parameters
  exactly and do not claim a variant is active without observed UI, DOM,
  storage, or network evidence.
- Use a fresh browser session or clear Optimizely localStorage before changing
  variants so a previous assignment cannot affect the result.
- Localhost and `dev-*` systems may need one patient retry after a slow initial
  load. Report the exact timeout or loading blocker if the retry fails.
- For a basket or checkout flow requiring a buyable item, prefer
  `/dummy-testbestellung/`. If it is unavailable, use a non-sold-out product and
  report the substitution; do not mistake an unavailable product for a flow
  failure unless that behavior is under test.

## Evidence

Return `PASS`, `FAIL`, or `BLOCKED`. Include the URL/environment, headed or
headless mode, scenario, commands, user actions, expected versus actual state,
key observations, and evidence locations. Summarize relevant console and
network failures instead of dumping raw logs. A browser `PASS` must be based on
observed behavior, not code inspection alone.
