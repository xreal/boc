---
name: Jira And Confluence
description: Finds and cites bounded Jira and Confluence context. Use when researching tickets, linked issues, acceptance criteria, constraints, or supporting pages.
---

# Jira And Confluence

Use Bergflow's native Jira and Confluence read tools for source context. Start
from the requested issue or a focused search; do not crawl broadly. If the
native tools are unavailable, report the missing capability rather than adding
or assuming an MCP integration.

- Follow Jira links only one level unless the user requests a specific deeper
  item.
- Open Confluence pages only when the ticket, repository, or focused search
  indicates relevance.
- Prefer current acceptance criteria, constraints, and recent authoritative
  comments over copied summaries.
- Cite issue keys, page titles, URLs, and update timestamps when freshness
  matters.
- Distinguish source facts, repository evidence, and inference.
- Do not download attachments automatically or reproduce large source bodies.

For a Jira write, call `bergflow_jira_write` with `phase: "prepare"`, pass its
returned `questionInput` unchanged to OpenCode's `question` tool, and call the
same mutation with `phase: "execute"` only when the user selects **Approve exact
change**. Never treat chat text, prior approval, or changed fields as approval.
