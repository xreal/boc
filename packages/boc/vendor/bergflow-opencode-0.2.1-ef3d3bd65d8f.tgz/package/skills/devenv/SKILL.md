---
name: Development Environment
description: Required before running local Bergfreunde project tests, Composer scripts, checks, migrations, module sync, frontend build/dev, OpenAPI generation, or Argo jobs. Uses verified devenv wrappers instead of host runtimes.
---

# Development Environment

`devenv` is a local-only wrapper around Docker Compose. Do not use these
commands for CI, staging, or production. In a Bergfreunde development checkout,
prefer `devenv ...` over running host Composer, PHPUnit, PHP, Python, or
migration tools directly. Frontend npm commands are the exception when local
Node satisfies the target package's `engines.node` requirement.

Before relying on a command, locate the active `devenv` executable or wrapper
and verify behavior against its `devenv.sh`, generated help, or completions. Do
not assume a user-specific absolute installation path and do not infer behavior
from other skills. If `devenv` is unavailable, report the environment gap rather
than substituting raw Docker commands without approval.

## Safety Rules

Do not run these unless the user explicitly asks for them or approves the exact
command:

```bash
devenv prepare-shop
devenv reset
devenv clean
devenv destroy
devenv init
devenv fix
```

- `prepare-shop` runs Ansible, decrypts or generates local config and env files,
  and copies assets into the shop source.
- `reset` stops containers and prunes Docker volumes.
- `clean` stops containers and runs `git clean -fxd` in `src`.
- `destroy` stops containers and prunes Docker images and volumes.
- `init` performs a full first-time setup chain.
- `fix` runs cache clearing, migrations, module sync, Composer install, and
  frontend install/build.

## Container Shells

Use `devenv ssh` to enter or execute inside a running Docker service.

```bash
devenv ssh <service>
devenv ssh <service> <shell-or-command> [args...]
```

```bash
devenv ssh shop
devenv ssh jobs
devenv ssh redis
devenv ssh shop /bin/sh -c 'php -v'
```

Completion may list service names such as `api-php81`, `api-php83`, `cypress`,
`db`, `db-ci`, `jobs`, `lb`, `mapp-order-tracking`, `rabbit`, `redis`, `shop`,
and `worker-order-tracking`. Verify the current list before relying on it.

## Composer And NPM

Use `devenv composer` for Composer scripts inside PHP project containers. The
command requires both a server or project and a Composer command.

```bash
devenv composer <server> <composer-command> [args...]
devenv composer-install <server>
devenv composer-update <server>
```

Examples:

```bash
devenv composer shop install
devenv composer shop phpunit source/Bergfreunde/Tests/SomeTest.php
devenv composer jobs phpcs
devenv composer services phpmd
devenv composer oms-api phpstan
devenv composer-install shop
devenv composer-install eventdb-api
devenv composer-update services
```

Supported server patterns:

- Default Composer CI containers: `shop`, `jobs`, `services`, `common`, and
  other `<server>-composer-ci` services that exist in Docker Compose.
- API containers: pass `<api>-api`, for example `oms-api`, `catalog-api`,
  `eventdb-api`, `time-management-api`, `wms-api`, `pimdata-api`, `reviews-api`,
  `storefront-api`, `pim-pim-api`, `sap-sap-api`, `sap-hub-api`, `im-im-api`, or
  `procurement-procurement-api`.
- NPM-backed contexts: `sst`, `jobsite`, and `sf` are routed through `npm` by
  the `composer` wrapper.

Use `devenv npm ...` only as an alias for `devenv composer ...`; it does not run
arbitrary host npm.

```bash
devenv npm sst test
devenv composer jobsite install
```

## Tests And Checks

`devenv test` requires a server and a test or check command. Do not assume
`devenv test shop` alone runs all tests; the implementation delegates to
`devenv composer <server> <args...>` and needs arguments.

```bash
devenv test <server> <command> [args...]
devenv test <server> -ls
```

Typical test servers include `*-api`, `jobs`, `services`, `shop`, and `sst`.

Examples:

```bash
devenv test shop phpunit
devenv test shop phpunit source/Bergfreunde/Tests/ShopTest.php
devenv test shop phpunit source/Bergfreunde/Tests/Twig
devenv test shop phpunit -- --filter testSpecificCase
devenv test jobs phpunit
devenv test services phpunit
devenv test oms-api phpunit
devenv test shop -ls
```

For the shop, verify the current Composer script before relying on details. The
known `phpunit` script uses the shop PHPUnit config and accepts extra
non-option arguments for a single file or directory. Use `--` before PHPUnit
options such as `--filter` so Composer does not consume them.

Verified top-level shop checks may include:

```bash
devenv phpcs-shop
devenv phplint-shop
```

There is no known top-level `devenv phpmd` or `devenv phpmd-shop` command. Run
`phpmd`, `phpstan`, `phpcs`, or `phplint` through Composer when the target
project's `composer.json` defines the script.

```bash
devenv composer shop phpmd
devenv composer shop phpcs
devenv composer services phpmd
devenv composer services phpstan
devenv composer jobs phpcs
devenv composer <api>-api phpcs
devenv composer <api>-api phpstan
```

If unsure which scripts exist, list them first:

```bash
devenv composer <server> run-script -l
```

## Shop Database And Cache

Use these for day-to-day shop database maintenance after code or schema
changes.

```bash
devenv migration [doctrine-migration-args...]
devenv im-migration
devenv update-views
devenv clear-cache
```

Known behavior:

- `migration` without args runs shop Doctrine migrations to latest and then
  clears cache.
- `migration <args...>` passes args to `./tools/bf-doctrine-migrations -n
  <args...>` and then clears cache.
- `im-migration` runs IM Doctrine migrations for normal and CI migration
  contexts.
- `update-views` runs `php source/bin/view-updater.php` in the `shop` container.
- `clear-cache` flushes Redis and removes shop and load-balancer cache files.

Typical sequence after migration changes:

```bash
devenv migration
devenv update-views
devenv clear-cache
```

## Shop Modules And Frontend

Use these for OXID module and shop frontend work.

```bash
devenv module-sync
devenv frontend-install
devenv frontend-build
devenv frontend-dev
```

Known behavior:

- `module-sync` runs `php source/bin/moduleSync.php` through the shop Composer
  container.
- `frontend-install` runs `npm i` in the `node` container.
- `frontend-build` runs `npm run build` in the `node` container.
- `frontend-dev` runs `npm run dev` in the `node` container.

There is no verified top-level `devenv frontend-test` command. Shop frontend
tests are defined in the relevant `package.json`; inspect its current scripts
and Node engine before running them.

Prefer local npm when the local Node version satisfies that package's
`engines.node` requirement. Check both values rather than relying on a recorded
version:

```bash
node -v
```

Typical focused shop frontend commands are:

```bash
npm test
npm test -- components/elements/button
npm test -- components/elements/button/index.spec.tsx
npm test -- --runTestsByPath components/elements/button/index.spec.tsx
npm run test:watch -- components/elements/button
```

Use `devenv ssh node ...` only as fallback when local Node is incompatible and
the `node` service is already running:

```bash
devenv ssh node npm test -- components/elements/button
```

If local Node is incompatible and `node` is not running, do not invent a
`devenv frontend-test` command. Either use a verified frontend wrapper or ask
before using a raw `docker compose run --rm node ...` command.

## OpenAPI

Use `openapi-generate` after changing API specs.

```bash
devenv openapi-generate <api|all|spec>
devenv openapi-lint <api|all|spec>
```

Examples:

```bash
devenv openapi-generate spec
devenv openapi-generate oms
devenv openapi-generate eventdb
devenv openapi-generate all
devenv openapi-lint oms
```

Known behavior:

- An argument is required; no-argument `openapi-generate` exits with usage.
- `spec` bundles matching specs and returns before starting API generator
  profiles.
- `all` processes all `*/spec/main.yaml` files and starts the `openapi` Docker
  profile.
- A specific value processes specs whose path contains that value and starts
  the `<value>-api` Docker profile.
- The command starts `redocly` and `bruno`, writes bundled specs to each
  `spec/out/main.yaml`, writes JSON specs under `/api-specs`, and converts Bruno
  collections.

## Argo Jobs

Use `devenv argo-jobs` for local execution of jobs that have an Argo-style
Dockerfile.

```bash
devenv argo-jobs <domain> <job-name> [--no-build|-B] [--target|-t <target>] [--interactive|-i] [--] [command...]
```

Requirements and behavior:

- The Dockerfile must exist at `src/<domain>/jobs/<job-name>/Dockerfile`.
- By default the command builds before running.
- `--no-build` or `-B` skips the build.
- `--target <target>` or `-t <target>` sets the Docker build target.
- `--interactive` or `-i` adds interactive terminal flags.
- Use `--` before a custom command so option parsing stops.

Examples:

```bash
devenv argo-jobs onlineshop create-pa-stats --target test
devenv argo-jobs sap sap-sbm-sync --no-build
devenv argo-jobs pim akeneo-pim-sync --interactive -- /bin/bash
devenv argo-jobs <domain> <job-name> -- python main.py --debug
```

## Jobs And Services Contexts

There is no top-level `devenv jobs` command in the known help. Use `jobs` as a
server or service context.

```bash
devenv composer jobs <composer-command>
devenv test jobs <test-command>
devenv ssh jobs
```

`devenv services` is a top-level command, but it opens the PHP services
container interactively. For repeatable commands, prefer the `services` context
through `composer`, `test`, or `ssh`.

```bash
devenv services
devenv composer services <composer-command>
devenv test services <test-command>
devenv ssh services
```

Python contexts are separate wrappers when needed:

```bash
devenv pyjobs <command>
devenv pyservices <command>
```

## Agent Defaults

- Prefer the narrowest verified command for the project area.
- Do not invent `devenv` aliases; check the wrapper first.
- For Composer checks, list scripts with
  `devenv composer <server> run-script -l` when the script name is uncertain.
- For OpenAPI generation, pass an explicit target such as `spec`, `all`, or the
  API name.
- For jobs, distinguish PHP `jobs` context from Python `pyjobs` and Argo
  `argo-jobs`.
- Ask before running lifecycle or destructive commands listed in Safety Rules.
