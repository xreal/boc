---
name: Grilling
description: Stress-tests a plan, design, or decision through a one-question-at-a-time interview. Use only when the user explicitly asks to be grilled or requests an adversarial stress-test.
---

# Grilling

Use this as an interview, not as permission to implement. Do not invoke it for
ordinary clarification, planning, review, or architecture discussion.

First inspect the relevant repository code, tests, guidance, and read-only
history needed to establish facts. Do not ask the user for information that can
be found safely in the codebase. Keep inspection read-only unless the user ends
the interview and separately requests implementation.

Identify the decision tree and start with the choice that constrains the most
later choices. Ask exactly one decision per OpenCode questioning-tool call and
wait for its answer before making another call. Do not ask grilling questions
as ordinary prose when the questioning tool is available.

Make each question easy to scan and quick to understand. Use plain language, a
short heading, one concise sentence for the decision, and short option labels.
Avoid compound questions, long preambles, unexplained jargon, and options that
differ only subtly. Put the recommended option first and mark it `Recommended`.
Each question must communicate:

- the decision and why it matters now;
- a recommended answer based on known facts;
- the concise tradeoff or consequence of that recommendation;
- the options that genuinely remain open.

Challenge vague answers, hidden assumptions, unowned risks, and contradictions
directly, but do not repeat a resolved point unless new information invalidates
it. Decisions belong to the user; recommendations belong to the interviewer.

Maintain a compact list of resolved and open decisions in the conversation
only. Do not create files, reports, or persisted tracking by default. Normally
finish within 15 questions by prioritizing choices that affect scope,
interfaces, data, failure behavior, security, operability, testing, rollout,
and reversibility. If important choices remain, summarize them and ask whether
the user wants to continue rather than silently expanding the interview.

At the end, summarize the shared understanding, resolved tradeoffs, open risks,
and recommended direction. Do not edit code or enact the plan until the user
explicitly confirms that the summary matches their understanding. That
confirmation does not authorize Git operations or remote writes.
