---
name: BrowserStack Test Management
description: Uses optional BrowserStack Test Management context for testcase research and drafting. Use when mapping Jira acceptance criteria to TC-* coverage or proposing testcase changes.
---

# BrowserStack Test Management

This is an optional testcase-drafting mode. Use it only for an explicit
testcase request or supplied context containing `TC-*`, `TP-*`, or `STP-*`
references. It does not replace a normal independent verification pass.

First detect whether configured BrowserStack Test Management read tools are
visible. If not, continue from Jira and repository evidence and state that the
optional integration was unavailable. Use direct read-only lookup tools for
narrow requests; delegate specialist assessment only when it adds clear value.

Use only BrowserStack Test Management reads: testcase, folder, template, run,
plan, and sub-plan listing or lookup. The BrowserStack MCP also exposes device,
execution, accessibility, upload, creation, update, result, and AI-agent tools;
those are outside this skill. Do not call them even if the user's OpenCode
permissions expose them.

Use BrowserStack Test Management project `PR-39` for testcase reads,
references, and proposed sync handoffs. Do not invent folder IDs, account
states, fixtures, environments, locales, or test data. Mark unknowns as open
questions or assumptions. If repository evidence can establish required data
or backend setup, document it as developer setup; never mutate data while
drafting a testcase.

Preserve `TC-*`, `TP-*`, and `STP-*` identifiers and link recommendations to
Jira acceptance criteria. Draft testcase proposals in chat with title,
description, priority, useful preconditions, realistic test data, environment or
locale, atomic manual steps, expected results for meaningful steps, negative or
edge coverage, tags or components, automation status, folder context, and
traceability. Prefer frontend-executable cases. Call backend or data setup
developer setup rather than presenting it as a normal manual step.

Pay particular attention when relevant to checkout, basket, registration,
payment, tracking, locale or domain differences, product availability,
authentication state, validation, and experiment variants. Use a supplied
`testcase-examples.md` as the project source of truth for wording, glossary, and
abbreviations.

Never create or update BrowserStack projects, folders, cases, runs, plans,
results, attachments, or generated automation. A human must review every draft
before any separately approved sync outside this agent.

Current tool names are sourced from BrowserStack's official MCP server. Treat a
missing or renamed read tool as an unavailable capability, not a reason to ask
for broader permissions.

## Output

Return these concise Markdown sections:

1. `Recommendation`: `CREATE`, `ADAPT`, or `NO CHANGE` with a one-sentence
   rationale.
2. `Testcase Draft`: case ID (`TC-*`, other existing ID, or `NEW`), title,
   description, priority, preconditions, test data, environment or locale,
   numbered steps with expected results, negative or edge coverage, tags or
   components, automation status, folder context, traceability, and open
   questions.
3. `Browser Evidence Prompt`: a focused follow-up using `browser-qa` covering
   the most important UI path when browser evidence would add value. Include
   known target URL or environment, exact UI area, required evidence, useful
   screenshots, and tracking or network checks. State when it gathers drafting
   evidence rather than pass/fail validation. List missing URL, fixture,
   account-state, or environment input instead of inferring it. Write `Not
   needed` when browser evidence adds no value.
4. `Notes`: integration availability, cases inspected, assumptions,
   unverifiable facts, and the human review required before sync.
