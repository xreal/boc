---
name: Code Review
description: Reviews completed diffs, branches, or pull requests for requirements fidelity, defects, regressions, security risks, and missing tests. Use for an explicit review target, not casual code explanation.
---

# Code Review

Use this skill only for a completed or explicitly delegated review target. Act
as a read-only reviewer. Do not edit code, persist a generated report, mutate
Git or remotes, or create run state. Do not use parallel subagents or introduce
a workflow engine. Focused read-only inspection is allowed.

## Establish Scope

Pin the review scope before judging the change:

1. Record the delegated target, base, PR, commit range, or supplied diff. Treat
   a supplied diff as complete only when its included files and worktree state
   are explicit; otherwise augment it with read-only repository inspection.
2. Resolve target and base with an unambiguous read-only ref check. For a branch
   or PR, validate the merge base; never silently substitute or infer a base.
3. Record resolved object IDs and the exact comparison. Inspect the commit list
   and aggregate diff so separate intent-changing commits are not overlooked.
4. When the delegated target includes the current worktree, include committed
   target changes, staged changes, unstaged changes, and relevant untracked
   files. Use status to enumerate all classes; read relevant untracked files
   directly because ordinary diffs omit them.
5. Check renames, deletions, generated files, submodules, and ignored files only
   where status, delegation, or repository rules include them.

If a ref does not resolve, the merge base is unavailable, PR metadata conflicts
with local state, or the target/base remains ambiguous, return `BLOCKED`. State
what is validated and missing; never claim completeness for uncertain scope.
An empty but valid scope is not a finding.

Do not checkout, switch, fetch, pull, stash, reset, clean, stage, or commit. Do
not write Jira, GitHub, BrowserStack, or other remote systems.

## Collect Intent

Before reviewing behavior, collect the narrowest authoritative intent sources:

- Jira acceptance criteria and current authoritative constraints;
- the original user request and review delegation;
- an accepted implementation plan or PR description;
- explicit non-goals and approved scope changes;
- applicable `AGENTS.md`, `CONTRIBUTING` guidance, domain skills, and ADRs.

Distinguish binding requirements from background, proposals, and inference.
Record source identifiers, paths, sections, links, or quoted criterion text.
Prefer newer explicit decisions when sources conflict, but report an unresolved
material conflict as an assumption or blocker rather than choosing silently.
If no authoritative product specification exists, say so; review stated intent
and engineering risk without inventing acceptance criteria.

## Pass 1: Requirements Fidelity

Perform both passes sequentially so neither masks the other. Run requirements
first and inventory requested outcomes, constraints, and non-goals, then inspect
the complete scope for:

- missing or only partially implemented criteria;
- behavior that implements a criterion incorrectly;
- unrequested product behavior, dependencies, or scope expansion;
- changed defaults or exclusions that contradict the stated intent;
- claims in the plan or PR description unsupported by the diff or checks.

For each candidate, quote or precisely cite the criterion or source and connect
it to changed-file evidence. Do not treat a preferred design as a requirement.

## Pass 2: Engineering Risk

Only after the fidelity pass, independently trace the changed behavior through:

- changed interfaces, contracts, serialization, and all relevant callers;
- invariants, boundary values, malformed input, failure paths, and recovery;
- authorization, secrets, injection, privacy, and other trust boundaries;
- performance, resource bounds, concurrency, ordering, and retries when relevant;
- configuration, migrations, compatibility, rollout, and mixed-version states;
- tests at stable seams, including important negative and regression cases.

Inspect surrounding code needed to understand impact, not only changed lines.
Run focused read-only checks when they materially improve confidence. Report
exact commands and outcomes; do not imply unrun or blocked checks passed.

Apply only this small design baseline where it predicts a concrete maintenance
or defect risk:

- speculative abstraction added without a current need;
- shotgun change scattering one policy across unrelated locations;
- shallow pass-through layers that obscure the owning behavior;
- duplicated policy that can diverge;
- behavior placed at the wrong ownership seam;
- tests coupled to implementation details instead of observable behavior.

Repository standards override this baseline. Skip formatting, naming, imports,
and other style already enforced by tooling, and avoid preference-only findings.

## Validate Findings

Before reporting any candidate, verify all of the following:

- The reviewed diff introduces or materially worsens it.
- A concrete input, state, sequence, or future change triggers the problem.
- The user-visible, operational, security, or maintenance failure is stated.
- File and line evidence supports the causal claim.
- A concise remediation direction exists without prescribing a full rewrite.

Label confidence separately from severity:

- `Confirmed`: direct code evidence or a focused check demonstrates the failure.
- `Likely`: control/data-flow evidence strongly predicts the stated failure.
- `Risk`: impact is credible, but missing environment or runtime evidence keeps
  the trigger uncertain; state what evidence would resolve it.

Do not report a pre-existing issue as a finding. Put it under residual risk
unless this change exposes it, expands its blast radius, or makes it newly
reachable.

## Severity

- `HIGH`: a realistic path can cause data loss or corruption, security or
  privacy breach, major outage, or failure of a core requirement, with broad
  impact or difficult recovery.
- `MEDIUM`: a realistic path causes materially wrong behavior or regression for
  a meaningful subset, but impact is bounded, recoverable, or has a workaround.
- `LOW`: a narrow defect or concrete maintainability/test weakness can cause a
  bounded future failure; it is not style, polish, or optional improvement.

Severity measures impact and likelihood, not confidence. Do not inflate a
speculative `Risk` or hide high impact merely because evidence is incomplete.

## Response

Return concise sections in this order:

1. `Findings`: one actionable list ranked HIGH, MEDIUM, LOW. Each item includes
   severity, `Requirements` or `Engineering risk`, confidence label, location,
   trigger and failure, evidence, source citation when applicable, and remedy.
2. `Review scope`: target, base, resolved comparison, included worktree state.
3. `Intent sources`: authoritative sources, conflicts, and absent specification.
4. `Requirements pass`: coverage summary and criteria/evidence gaps.
5. `Engineering pass`: risk summary and checks performed or blocked.
6. `Assumptions and residual risks`: uncertainty and relevant pre-existing risk.

Keep the two pass summaries distinct though findings share one ranked list. If
none are validated, state both passes found no actionable issues. Completion
requires pinned scope, cited intent, both passes, diff causality, reported
checks, and explicit residual uncertainty.
